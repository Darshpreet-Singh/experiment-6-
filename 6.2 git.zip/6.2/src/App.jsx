import React, { useState } from "react";
import "./App.css";

function App() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [emailValid, setEmailValid] = useState(false);
  const [passwordValid, setPasswordValid] = useState(false);

  const validateEmail = (value) => {
    setEmail(value);
    const emailPattern =
      /^(?!.*\.(com|in|org|net|edu|gov)@)[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)?@[a-zA-Z]+\.[a-zA-Z]{2,}$/;
    setEmailValid(emailPattern.test(value));
  };

  const validatePassword = (value) => {
    setPassword(value);
    const passwordPattern =
      /^[A-Z](?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z0-9@$!%*?&]{4,}$/;
    setPasswordValid(passwordPattern.test(value));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(emailValid && passwordValid ? "Login Successful ✅" : "Invalid Details ❌");
  };

  return (
    <div className="container">
      <form onSubmit={handleSubmit} className="form">

        <h2 className="title">Login Page</h2>

        <input
          type="text"
          placeholder="Enter Email"
          value={email}
          onChange={(e) => validateEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => validatePassword(e.target.value)}
        />

        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default App;