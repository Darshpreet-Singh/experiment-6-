import { useState } from 'react'
import './App.css'

function App() {

  const initialFormState = {
    firstName: '',
    lastName: '',
    address: '',
    gender: '',
    DoB: '',
    skills: []
  }

  const [formData, setFormData] = useState(initialFormState)

  // Today's date (YYYY-MM-DD)
  const today = new Date().toISOString().split('T')[0]

  // Handle input change
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target

    if (type === 'checkbox') {
      setFormData(prev => ({
        ...prev,
        skills: checked
          ? [...prev.skills, value]
          : prev.skills.filter(skill => skill !== value)
      }))
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }))
    }
  }

  // Handle submit
  const handleSubmit = (e) => {
    e.preventDefault()

    const details = `
Submitted Details:

First Name: ${formData.firstName}
Last Name: ${formData.lastName}
Address: ${formData.address}
Gender: ${formData.gender}
Date of Birth: ${formData.DoB}
Skills: ${formData.skills.length > 0 ? formData.skills.join(', ') : 'None'}
    `

    alert(details)
    console.log(formData)
  }

  // Clear form
  const handleClear = () => {
    setFormData(initialFormState)
  }

  return (
    <>
      <form onSubmit={handleSubmit}>
        <fieldset>

          First Name:
          <input
            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
            placeholder="Enter your name"
          />
          <br /><br />

          Last Name:
          <input
            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
            placeholder="Enter your name"
          />
          <br /><br />

          Address:
          <textarea
            name="address"
            value={formData.address}
            onChange={handleChange}
            placeholder="Enter your address"
          ></textarea>
          <br /><br />

          Gender:
          <input
            type="radio"
            name="gender"
            value="Male"
            checked={formData.gender === 'Male'}
            onChange={handleChange}
          /> Male
          <input
            type="radio"
            name="gender"
            value="Female"
            checked={formData.gender === 'Female'}
            onChange={handleChange}
          /> Female
          <br /><br />

          DoB:
          <input
            type="date"
            name="DoB"
            value={formData.DoB}
            onChange={handleChange}
            max={today}
          />
          <br /><br />

          Skills:
          <input type="checkbox" value="Designing" onChange={handleChange} /> Designing
          <input type="checkbox" value="CSS" onChange={handleChange} /> CSS
          <input type="checkbox" value="HTML" onChange={handleChange} /> HTML
          <input type="checkbox" value="Java" onChange={handleChange} /> Java
          <input type="checkbox" value="Python" onChange={handleChange} /> Python
          <input type="checkbox" value="C++" onChange={handleChange} /> C++
          <input type="checkbox" value="C" onChange={handleChange} /> C
          <br /><br />

          <input type="submit" value="Submit" />
          <input type="button" value="Clear Form" onClick={handleClear} />

        </fieldset>
      </form>
    </>
  )
}

export default App